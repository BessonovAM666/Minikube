
# Kubernetes Web Application Deployment — DevSecOps Practice

📦 Развёртывание веб-приложения в Kubernetes-кластере Minikube (RedOS 8)  
👤 Автор: Bessonov Andrey

---

## 🧰 Используемые технологии

- RedOS 8 (внутри VMware)
- Docker
- Minikube
- kubectl
- Kubernetes YAML: ConfigMap, Secret, Deployment, Service
- Собственный Docker-образ на базе nginx

---

## 📁 Состав проекта

- `mongo-config.yaml` — ConfigMap с адресом MongoDB
- `mongo-secret.yaml` — логин и пароль (base64, Secret)
- `mongo-deployment.yaml` — деплоймент и сервис MongoDB
- `webapp-deployment.yaml` — деплоймент и NodePort-сервис веб-приложения
- `k8s-resources.txt` — вывод `kubectl get all -o wide`
- `inventory.txt` — информация об окружении
- `screenshot.png` — подтверждение работы веб-приложения

---

## 🌐 Результат

Приложение доступно в браузере по адресу:  
`http://192.168.49.2:30100`

![Скриншот](screenshot.png)

---

## 📋 Инвентаризация

См. файл `inventory.txt` для сведений о кластере.

---

## 🔐 Безопасность

Пароли и логины используются через Kubernetes Secret и не хранятся в открытом виде.
